#!/bin/sh
#cd /v2
SHELL_FOLDER=$(DIRNAME $(READLINK -F "$0"))
cd SHELL_FOLDER
./run
