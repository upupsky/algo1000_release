1.please ./run to execute the application. if alert the message like this "./run: /lib64/libstdc++.so.6: version`GLIBCXX_3.4.21' not found (required by ./run)",you can read the blog, https://blog.csdn.net/weixin_42195004/article/details/103672155
2.startup autorun setting, edit "/etc/rc.d/rc.local", add current file autorun.sh path in the end.

